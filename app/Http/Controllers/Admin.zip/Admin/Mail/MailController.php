<?php namespace App\Http\Controllers\admin\mail;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Mail,DB,Session;
use Illuminate\Http\Request;

class MailController extends Controller {

	

}
