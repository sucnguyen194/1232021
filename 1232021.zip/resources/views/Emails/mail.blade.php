<div>
  <table align="center" cellpadding="0" cellspacing="0" style="background-color:#d4eefb;margin:auto;border-collapse:collapse;width:700px;font-family:verdana;color:#222">
    <tbody>
      <tr>
        <td style="padding:20px 30px;width:auto"><table cellpadding="0" cellspacing="0" style="border-collapse:collapse;background-color:white;width:700px;margin:auto">
            <tbody>
              <tr>
                <td style="background-color:#00c0f1"><table cellpadding="0" cellspacing="0" style="border-collapse:collapse;width:100%">
                    <tbody>
                      <tr style="border:1px solid #b3e4fc">
                        <td style="width:80%;font-size:22px;font-family:arial;color:#ffffff;font-weight:bold;padding:25px 0 20px 20px"> Khách hàng đăng ký e-mail,<br></td>
                        <td style="padding-right:20px;width:50%"></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
              <tr style="border-left:1px solid #b3e4fc;border-right:1px solid #b3e4fc">
                <td height="5"></td>
              </tr>
              <tr style="border-left:1px solid #b3e4fc;border-right:1px solid #b3e4fc;border-bottom:1px solid #b3e4fc">
                <td><table cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:12px">
                    <tbody>
                      <tr>
                        <td style="padding-left:20px;padding-right:20px;padding-bottom:30px;font-family:verdana,arial;padding-top:10px"><h3>Thông tin liên hệ</h3>
                          <table>
                            <tbody>
                            
                              <tr>
                                <td>Tên khách hàng: </td>
                                <td>{{$name}} </td>
                              </tr>
                                                           <tr>
                                <td>Email </td>
                                <td>{{$email}} </td>
                              </tr> 
                            </tbody>
                          </table>
                          <!--<h3>Nội dung đặt hàng</h3>-->
                          <!--<table id="m_3811412088833349531m_-910912962702402442nddh" style="border-collapse:collapse;width:100%;color:#333" border="1">
                            <tbody>
                              <tr style="background-color:#fc0;font-weight:bold">
                                <td style="padding:4px">STT</td>
                                <td style="padding:4px">Mã kho</td>
                                <td style="padding:4px">Sản phẩm</td>
                                <td style="padding:4px">Đơn giá</td>
                                <td style="padding:4px">Số lượng</td>
                                <td style="padding:4px">Tổng tiền</td>
                                <td style="padding:4px">Ghi chú</td>
                              </tr>
                              <tr>
                                <td style="padding:4px">1</td>
                                <td style="padding:4px">BANM033</td>
                                <td style="padding:4px"><a href="https://www.hanoicomputer.vn/ban-laptop-go-soi-fan/p15177.html" target="_blank" data-saferedirecturl="https://www.google.com/url?q=https://www.hanoicomputer.vn/ban-laptop-go-soi-fan/p15177.html&amp;source=gmail&amp;ust=1534696004413000&amp;usg=AFQjCNHj_CFsq1Yr_lv2wIxoocB2_ypdeg"><b>Bàn Laptop gỗ sồi + Fan</b></a></td>
                                <td style="padding:4px">99.000 <u>đ</u></td>
                                <td style="padding:4px">1</td>
                                <td style="padding:4px;font-weight:bold"> 99.000 <u>đ</u></td>
                                <td style="padding:4px"></td>
                              </tr>
                              <tr class="m_3811412088833349531m_-910912962702402442txt_16">
                                <td class="m_3811412088833349531m_-910912962702402442txt0" colspan="5" align="right" style="padding:4px"> Tổng tiền </td>
                                <td class="m_3811412088833349531m_-910912962702402442txt_right" colspan="2" style="padding:4px;font-weight:bold;color:#e00"> 99.000 <u>đ</u></td>
                              </tr>
                            </tbody>
                          </table>--></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
              <tr>
                <td style="min-height:1px;max-height:1px;height:1px;line-height:1px;background:#b3e4fc"></td>
              </tr>
            </tbody>
          </table></td>
      </tr>
    </tbody>
  </table>
  <div class="yj6qo"></div>
  <div class="adL"> </div>
</div>
