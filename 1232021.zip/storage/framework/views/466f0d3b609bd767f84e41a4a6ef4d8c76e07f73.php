<?php $__env->startSection('title'); ?> <?php echo e(optional($setting)->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('site_name'); ?> <?php echo e(optional($setting)->name); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('url'); ?> <?php echo e(route('home')); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?> <?php echo optional($setting)->description_seo; ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('keywords'); ?><?php echo optional($setting)->keyword_seo; ?><?php $__env->stopSection(); ?>
<?php $__env->startSection('image'); ?> <?php echo e(asset(optional($setting)->og_image ?? optional($setting)->logo)); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(redirect_lang()); ?>

<!-------------------------->
<!-----------SOURCSE----------->
<!-------------------------->
<?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('user.logout')); ?>">Đăng xuất</a>
<?php endif; ?>

<!-------------------------->
<!-----------SOURCSE----------->
<!-------------------------->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\1232021\resources\views/Layouts/home.blade.php ENDPATH**/ ?>