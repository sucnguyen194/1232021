
<?php $__env->startSection('title'); ?> Danh sách đường dẫn <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Bảng điều khiển</a></li>
                            <li class="breadcrumb-item active">Danh sách đường dẫn</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Danh sách đường dẫn</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-12">
                <div class="card-box table-responsive">
                        <div class="action-datatable mb-3">
                            <a href="<?php echo e(route('admin.alias.create')); ?>" class="btn btn-primary waves-effect width-md waves-light">
                                <span class="icon-button"><i class="fa fa-plus-circle"></i></span> Thêm mới</a>
                        </div>
                        <table id="datatable-buttons" class="table table-bordered table-striped table-hover bs-table" style="border-collapse: collapse; border-spacing: 0; ;">
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th style="width: 30%">Tiêu đề</th>
                                <th style="width: 30%">Đường dẫn</th>

                                <th>Ngày tạo</th>
                                <th>Hành động</th>
                            </tr>
                            </thead>

                            <tbody>
                            <?php $__currentLoopData = $alias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td ><?php echo e($item->id); ?></td>
                                    <td style="width: 30%"><?php echo e($item->model->name ?? $item->model->title); ?> </td>
                                    <td style="width: 30%"><?php echo e($item->alias); ?> </td>

                                    <td>
                                        <?php echo e($item->updated_at->diffForHumans()); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('admin.alias.edit',$item)); ?>" class="btn btn-purple waves-effect waves-light">
                                            <span class="icon-button"><i class="fe-edit-2"></i></span></a>

                                       <form method="post" action="<?php echo e(route('admin.alias.destroy',$item)); ?>" class="d-inline-block">
                                           <?php echo method_field('DELETE'); ?>
                                           <?php echo csrf_field(); ?>
                                           <button type="submit" class="btn btn-warning waves-effect waves-light" onclick="return confirm('Bạn có chắc muốn xóa?');"><span class="icon-button"><i class="fe-x"></i></span></button>
                                       </form>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
        <!-- end row -->

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- third party css -->
    <link href="<?php echo e(asset('admin/assets/libs/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/datatables/buttons.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/datatables/responsive.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

    <!-- Required datatable js -->
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>

    <script src="<?php echo e(asset('admin/assets/libs/switchery/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="https://coderthemes.com/adminox/layouts/vertical/assets/libs/select2/select2.min.js"></script>
    
    <script src="<?php echo e(asset('admin/assets/libs/autocomplete/jquery.autocomplete.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-filestyle2/bootstrap-filestyle.min.js')); ?>"></script>


    <!-- Init js-->
    <script src="<?php echo e(asset('admin/assets/js/pages/form-advanced.init.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('admin/assets/libs/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/datatables/buttons.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/libs/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/datatables/buttons.colVis.js')); ?>"></script>

    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>


    <!-- Responsive examples -->
    <script src="<?php echo e(asset('admin/assets/libs/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Datatables init -->
    <script src="<?php echo e(asset('admin/assets/js/pages/datatables.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\1232021\resources\views/Admin/Alias/list.blade.php ENDPATH**/ ?>