<?php $__env->startSection('title'); ?>
    Thông tin đơn hàng #<?php echo e($import->id); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid" id="update-import">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Bảng điều khiển</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.imports.index')); ?>">Danh sách nhập kho</a></li>
                            <li class="breadcrumb-item active">Thông tin đơn hàng #<?php echo e($import->id); ?></li>
                        </ol>
                    </div>
                    <h4 class="page-title">Thông tin đơn hàng #<?php echo e($import->id); ?></h4>
                </div>
            </div>
        </div>
        <!-- end page title -->
            <div class="row">
               <div class="col-lg-12">
                        <div class="card-box">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-2 font-weight-bold">Ngày nhập hàng</div>
                                    <div class="col-lg-10 font-weight-bold"><?php echo e($import->created_at->format('d/m/Y H:i')); ?></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-2 font-weight-bold">Người nhập hàng</div>
                                    <div class="col-lg-10 font-weight-bold"><a href="<?php echo e(route('admin.user.index',['id' => $import->user->id ?? 0])); ?>" target="_blank"><?php echo e($import->user->name ?? 'Tên trống hoặc đã xóa'); ?></a> </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-2 font-weight-bold">Nhà cung cấp</div>
                                    <div class="col-lg-10 font-weight-bold"><a href="<?php echo e(route('admin.user.index',['id' => $import->user->id ?? 0])); ?>" target="_blank"><?php echo e($import->agency->name ?? 'Tên trống hoặc đã xóa'); ?></a> </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-lg-12 font-weight-bold">Ghi chú</div>
                                    <?php if($import->note): ?>
                                    <div class="col-lg-12 mt-2 font-weight-bold">
                                        <textarea class="form-control" readonly rows="7"><?php echo $import->note; ?></textarea>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="button" class="btn btn-purple waves-effect waves-light" data-toggle="modal" data-target="#myModal"><span class="icon-button"><i class="fe-edit-2"></i></span> Sửa</button>

                                <div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                                    <form method="POST" action="<?php echo e(route('admin.imports.update',$import)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label class="font-weight-bold">Người nhập hàng</label>
                                                    <select class="form-control" name="user" v-model="update_import.admin" id="admins">
                                                        <option value="0">--Chọn người nhập hàng--</option>
                                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($user->id); ?>" <?php echo e($import->user->id == $user->id ? "selected" : ""); ?>><?php echo e($user->name ?? $user->account); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <p class="text-danger font-weight-bold mt-2" v-if="update_import.admin == 0">Vui lòng chọn người nhập hàng</p>
                                                </div>
                                                <div class="form-group">
                                                    <label class="font-weight-bold">Nhà cung cấp</label>
                                                    <select class="form-control" name="agency" v-model="update_import.agency" id="agencys">
                                                        <option value="0">--Chọn nhà cung cấp--</option>
                                                        <?php $__currentLoopData = $agencys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($agency->id); ?>" <?php echo e($import->agency->id == $agency->id ? "selected" : ""); ?>><?php echo e($agency->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <p class="text-danger font-weight-bold mt-2" v-if="update_import.agency == 0">Vui lòng chọn nhà cung cấp</p>
                                                </div>
                                                <div class="note-group">
                                                    <label class="font-weight-bold">Ghi chú</label>
                                                    <textarea class="form-control" rows="4" name="note"> <?php echo $import->note; ?></textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal"> Đóng</button>
                                                <button type="submit" name="send" value="user" :disabled="update_import.admin == 0 || update_import.agency == 0" class="btn btn-primary waves-effect waves-light" onclick="return confirm('Xác nhận thông tin?')"> <span class="icon-button"><i class="fe-plus"></i></span> Xác nhận</button>
                                            </div>
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                    </form>
                                </div><!-- /.modal -->

                            </div>
                            <div class="form-group">
                                <label class="font-weight-bold">Danh sách sản phẩm</label>
                                <table class="table table-bordered table-striped">
                                    <thead>
                                    <tr>
                                        <th>Tên sản phẩm</th>
                                        <th>Số lượng</th>
                                        <th>Giá nhập</th>
                                        <th>Thành tiền</th>
                                        <th>Hành động</th>
                                    </tr>
                                    </thead>
                                    <tbody class="show-card">
                                    <?php $__currentLoopData = $import->sessions()->get()->load('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1">SP</span>
                                                    </div>
                                                    <div class="form-control font-weight-bold"><?php echo e($item->product->name ?? "Sản phẩm đã xóa"); ?></div>
                                                </div>
                                               </td>
                                            <td>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1">SL</span>
                                                    </div>
                                                    <div class="form-control font-weight-bold"><?php echo e($item->amount); ?></div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                                    </div>
                                                    <div class="form-control font-weight-bold"><?php echo e(number_format($item->price_in)); ?></div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                                    </div>
                                                    <div class="form-control font-weight-bold"><?php echo e(number_format($item->price_in*$item->amount)); ?></div>
                                                </div>
                                            </td>
                                            <td><a href="javascript:void(0)" class="btn btn-purple waves-effect waves-light" v-on:click="getSession(<?php echo e($item->id); ?>)" data-toggle="modal" data-target="#product-item-<?php echo e($item->id); ?>"><span class="icon-button"><i class="fe-edit-2"></i></span> </a> <a href="<?php echo e(route('admin.destroy.session',$item->id)); ?>" class="btn btn-warning waves-effect waves-light" onclick="return confirm('Xóa sản phẩm?')"><span class="icon-button"><i class="fe-x"></i></span> </a></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>

                <?php $__currentLoopData = $import->sessions()->get()->load('product'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="product-item-<?php echo e($item->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
                        <form method="post" action="<?php echo e(route('admin.update.session',$item->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>Tên sản phẩm</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">SP</span>
                                                </div>
                                                <div class="form-control font-weight-bold"><?php echo e($item->product->name ?? 'Sản phẩm đã xóa'); ?>"</div>

                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Số lượng</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">SL</span>
                                                </div>
                                                <input type="number" name="amount" class="form-control text-primary font-weight-bold" oninput="validity.valid||(value = 1);" v-model="amount" v-bind:value="<?php echo e($item->amount); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Giá nhập</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                                </div>
                                                <input type="number" name="price" class="form-control text-primary font-weight-bold" oninput="validity.valid||(value = 0);" v-model="price" v-bind:value="<?php echo e($item->price_in); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label>Thành tiền</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                                </div>
                                                <div class="form-control font-weight-bold">{{ provisional.toLocaleString() }}</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary waves-effect" data-dismiss="modal"> Đóng</button>
                                        <button type="submit" class="btn btn-primary waves-effect waves-light" onclick="return confirm('Xác nhận thông tin?')"> <span class="icon-button"><i class="fe-plus"></i></span> Xác nhận</button>
                                    </div>
                                </div><!-- /.modal-content -->
                            </div><!-- /.modal-dialog -->
                        </form>
                    </div><!-- /.modal -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-12">
                    <form method="post" action="<?php echo e(route('admin.imports.update',$import)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    <div class="card-box">
                        <div class="row">
                            <div class="col-lg-4">
                                <label class="font-weight-bold">Tổng tiền</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                    </div>
                                    <div class="form-control font-weight-bold">{{ total.toLocaleString() }}</div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label class="font-weight-bold">Thanh toán</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                    </div>
                                    <input type="text" class="form-control text-primary font-weight-bold" v-model="checkout" name="checkout" oninput="validity.valid||(value = 0);" v-bind:VALUE="checkout">
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label class="font-weight-bold">Công nợ</label>
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1">VNĐ</span>
                                    </div>
                                    <div class="form-control font-weight-bold">{{ debts.toLocaleString() }}</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card-box text-center">
                        <a class="btn btn-purple waves-effect waves-light" href="<?php echo e(route('admin.imports.index')); ?>"><span class="icon-button"><i class="fe-arrow-left"></i></span> Quay lại</a>
                        <button type="submit" name="send" value="checkout" class="btn btn-primary waves-effect waves-light" onclick="return confirm('Xác nhận thông tin?')"> <span class="icon-button"><i class="fe-plus"></i></span> Xác nhận</button>
                    </div>
                    </form>
                </div>
            </div>
            <!-- end row -->
    </div>
<script>

    var app = new Vue({
       el:'#update-import',
       data: {
           total: <?php echo e($import->total); ?>,
           checkout: <?php echo e($import->checkout); ?>,
           debt: <?php echo e($import->debt); ?>,

           amount:0,
           price:0,

           update_import: {
               admin: <?php echo e($import->user->id); ?>,
               agency: <?php echo e($import->agency->id); ?>,
           }
       },
        methods:{
            getSession:function(id){
                fetch('<?php echo e(route('admin.ajax.session',':id')); ?>'.replace(':id',id)).then(function (response){
                    return response.json().then(function(data){
                        app.amount = data.amount;
                        app.price = data.price_in;
                    })
                })
            }
        },
        watch:{
            amount:function (val){
                this.amount = val;
            },
            price:function (val){
                this.price = val;
            },
            checkout:function(val){
                this.checkout = val
            }
        },
        computed:{
            provisional:function(){
                return this.amount * this.price;
            },
            debts:function(){
                return this.total - this.checkout;
            }
        }
    });

    function js_select2(){
        return $("#admins ,#agencys").select2()
            .on("select2:select", e => {
                const event = new Event("change", { bubbles: true, cancelable: true });
                e.params.data.element.parentElement.dispatchEvent(event);
            })
            .on("select2:unselect", e => {
                const event = new Event("change", { bubbles: true, cancelable: true });
                e.params.data.element.parentElement.dispatchEvent(event);
            });
    }
    $(document).ready(function(){
        js_select2();
    })
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <!-- Required datatable js -->
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>

    <script src="<?php echo e(asset('admin/assets/libs/switchery/switchery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.min.js')); ?>"></script>
    <script src="https://coderthemes.com/adminox/layouts/vertical/assets/libs/select2/select2.min.js"></script>
    
    <script src="<?php echo e(asset('admin/assets/libs/autocomplete/jquery.autocomplete.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/bootstrap-filestyle2/bootstrap-filestyle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/libs/custombox/custombox.min.js')); ?>"></script>
    <!-- Init js-->
    <script src="<?php echo e(asset('admin/assets/js/pages/form-advanced.init.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/libs/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('admin/assets/libs/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/datatables/buttons.bootstrap4.min.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/assets/libs/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/datatables/buttons.colVis.js')); ?>"></script>

    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.5/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.5/js/buttons.html5.min.js"></script>

    <!-- Responsive examples -->
    <script src="<?php echo e(asset('admin/assets/libs/datatables/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/libs/datatables/responsive.bootstrap4.min.js')); ?>"></script>

    <!-- Datatables init -->
    <script src="<?php echo e(asset('admin/assets/js/pages/datatables.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('admin/assets/libs/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- third party css -->
    <link href="<?php echo e(asset('admin/assets/libs/datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/datatables/buttons.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/datatables/responsive.bootstrap4.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/libs/custombox/custombox.min.css')); ?>" rel="stylesheet" type="text/css" >
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\1232021\resources\views/Admin/Import/show.blade.php ENDPATH**/ ?>